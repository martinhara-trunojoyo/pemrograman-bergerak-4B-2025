class Pantai {
  final String namaPantai;
  final String lokasi;
  final String deskripsi;
  final String gambar;

  Pantai({
    required this.namaPantai,
    required this.lokasi,
    required this.deskripsi,
    required this.gambar,
  });

}
